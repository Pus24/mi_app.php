<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="home.css"> <!-- Hoja de estilos -->
</head>
<body>
    <header>
        <h1>Bienvenido a la Clínica del Caribe</h1>
    </header>
    <nav>
        <ul>
            <li><a href="registro.php">Registro</a></li>
            <li><a href="login.php">Inicio de Sesión</a></li>
            <li><a href="agendar_cita.php">Agendar Citas</a></li>
            <li><a href="lista_citas.php">Lista de Citas Agendadas</a></li>
            <li><a href="lista_usuarios.php">Lista de Usuarios Registrados</a></li>
        <div class="logo-container"> <!-- Contenedor para el logo -->
            <img src="img/LogoClinica.png" alt="Logo" class="logo"> 
        </div>
        </ul>
    </nav>
    <footer>
        <p>&copy; 2024 Clínica C. Todos los derechos reservados.</p>
    </footer>
</body>
</html>