<?php
session_start();
require 'config.php'; // Incluye la configuración de la base de datos

// Manejo de la acción de eliminar una cita
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM citas WHERE id = $id");
    header("Location: lista_citas.php"); // Redirige después de eliminar
    exit();
}

// Manejo de la acción de guardar cambios en una cita
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = intval($_POST['id']);
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $id_medico = intval($_POST['id_medico']); // Obtener el id del médico

    // Actualiza la cita en la base de datos
    $conn->query("UPDATE citas SET fecha = '$fecha', hora = '$hora', id_medico = $id_medico WHERE id = $id");
    header("Location: lista_citas.php"); // Redirige después de guardar
    exit();
}

// Obtener la lista de citas
$result_citas = $conn->query("
    SELECT citas.id, medicos.nombre AS medico_nombre, medicos.especialidad, citas.fecha, citas.hora
    FROM citas
    JOIN medicos ON citas.id_medico = medicos.id
");

// Obtener la lista de médicos para el menú desplegable
$result_medicos = $conn->query("SELECT * FROM medicos");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Citas Agendadas</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Fuente general para el cuerpo */
        }
        .titulo-container {
            display: flex; /* Usar flexbox para alinear el título y el logo */
            justify-content: space-between; /* Espacio entre el título y el logo */
            align-items: center; /* Centrar verticalmente */
            margin: 20px; /* Margen alrededor del div */
            padding: 10px; /* Espaciado interno */
            background-color: #f9f9f9; /* Color de fondo */
            border-radius: 10px; /* Bordes redondeados */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Sombra para dar profundidad */
        }
        .titulo {
            font-family: 'Georgia', serif; /* Fuente elegante */
            font-size: 2.5rem; /* Tamaño de la fuente */
            color: #007BFF; /* Color azul */
            text-transform: uppercase; /* Convierte a mayúsculas */
            letter-spacing: 2px; /* Espaciado entre letras */
            margin: 0; /* Eliminar margen para evitar espacios extra */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2); /* Sombra de texto */
        }

        .logo {
            width: 7%; /* Ajustar el tamaño del logo */
            height: auto; /* Mantiene la relación de aspecto */
            max-height: 80px; /* Ajusta la altura máxima del logo para mantenerlo proporcionado */
        }
        
    </style>
</head>
<body>
    <div class="titulo-container">
        <h1 class="titulo">Lista de Citas Agendadas</h1>
        <img class="logo" src="img/LogoClinica.png" alt="Logo"> <!-- Asegúrate de que la ruta sea correcta -->
    </div>

    <link rel="stylesheet" href="lista_citas.css"> <!-- Hoja de estilos -->
    
    <!-- El resto de tu contenido -->

</head>
<body>

    <div class="header-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Médico</th>
                    <th>Especialidad</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($cita = $result_citas->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $cita['id']; ?></td>
                        <td><?php echo $cita['medico_nombre']; ?></td>
                        <td><?php echo $cita['especialidad']; ?></td>
                        <td><?php echo $cita['fecha']; ?></td>
                        <td><?php echo $cita['hora']; ?></td>
                        
                            <!-- Botones de editar y eliminar -->
                        <td>
                           <a href="lista_citas.php?action=edit&id=<?php echo $cita['id']; ?>" style="color: yellow; background-color: black; padding: 5px 10px; text-decoration: none; border-radius: 5px;">Editar</a>
                           <a href="lista_citas.php?action=delete&id=<?php echo $cita['id']; ?>" style="color: white; background-color: red; padding: 5px 10px; text-decoration: none; border-radius: 5px;" onclick="return confirm('¿Estás seguro de que deseas eliminar esta cita?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
    </div>

    <?php
    // Mostrar el formulario de edición si se solicita
    if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $cita = $conn->query("SELECT * FROM citas WHERE id = $id")->fetch_assoc();
        ?>
        
        <div class="edit-form-container"> <!-- Contenedor del formulario -->
            <form method="POST" action="">
            <h3>Editar Cita</h3>
                <input type="hidden" name="id" value="<?php echo $cita['id']; ?>">
                <input type="hidden" name="action" value="edit">
                
                <label for="id_medico">Selecciona un Médico:</label>
                <select name="id_medico" required>
                    <?php while ($medico = $result_medicos->fetch_assoc()): ?>
                        <option value="<?php echo $medico['id']; ?>" <?php echo $cita['id_medico'] == $medico['id'] ? 'selected' : ''; ?>>
                            <?php echo $medico['nombre'] . " - " . $medico['especialidad']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="fecha">Fecha:</label>
                <input type="date" name="fecha" value="<?php echo $cita['fecha']; ?>" required>
                <label for="hora">Hora:</label>
                <input type="time" name="hora" value="<?php echo $cita['hora']; ?>" required>
                <button type="submit">Guardar Cambios</button>
                <p><a href="index.php">Volver a la página principal</a></p>
            </form>
        </div>
        <?php
    }
    ?>
</body>
</html>
