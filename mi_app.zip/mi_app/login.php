<?php
session_start();
require 'config.php';
require 'funciones.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (verificarUsuario($conn, $username, $password)) {
        $_SESSION['username'] = $username;
        $message = "Inicio de sesión exitoso."; // Mensaje de confirmación
        header("Location: agendar_cita.php?message=" . urlencode($message)); // Redirige a listar_usuarios con mensaje
        exit();
    } else {
        $error_message = "Nombre de usuario o contraseña incorrectos."; // Mensaje de error
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="login.css"> <!-- Enlazar archivo CSS -->
</head>
<body>
    <div class="container">
        <img src="img/LogoClinica.png" alt="Logo" class="logo"><!-- Logo --> 
        <div class="form-container">
            <h2>Iniciar Sesión</h2>
            <?php if (isset($error_message)): ?>
                <p style="color: red;"><?php echo $error_message; ?></p> <!-- Muestra mensaje de error si existe -->
            <?php endif; ?>
            <form method="POST" action="">
                <label>Nombre de usuario:</label>
                <input type="text" name="username" required>
                <br>
                <label>Contraseña:</label>
                <input type="password" name="password" required>
                <br>
                <button type="submit">Iniciar Sesión</button>
            </form>
            <p>¿No tienes una cuenta? <a href="registro.php">Regístrate</a></p>
        </div>
    </div>
</body>
</html>
