<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Página Principal</title>
    <link rel="stylesheet" href="estilos.css"> <!-- Enlace a la hoja de estilos -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #4CAF50;
        }
        .button-container {
            margin: 20px 0;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            background-color: #007BFF;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .cerrar-sesion {
            background-color: #dc3545;
        }
        .cerrar-sesion:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h1>Acceso autorizado, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
    <p>
        <a href="logout.php" class="button cerrar-sesion">Cerrar sesión</a>
    </p>

    <!-- Botones de Login y Registro -->
    <div class="button-container">
        <a href="login.php" class="button iniciar-sesion">Iniciar Sesión</a>
        <a href="registro.php" class="button registrarse">Registrarse</a>
    </div>
</body>
</html>
