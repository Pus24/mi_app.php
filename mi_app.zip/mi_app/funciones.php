<?php
function registrarUsuario($conn, $username, $password, $telefono, $correo, $direccion) {
    // Hashear la contraseña
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Preparar la consulta SQL
    $stmt = $conn->prepare("INSERT INTO usuarios (username, password, telefono, correo, direccion) VALUES (?, ?, ?, ?, ?)");
    
    // Vincular parámetros
    $stmt->bind_param("sssss", $username, $hashed_password, $telefono, $correo, $direccion);
    
    // Ejecutar la consulta y devolver el resultado
    return $stmt->execute();
}

function verificarUsuario($conn, $username, $password) {
    $stmt = $conn->prepare("SELECT password FROM usuarios WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();
        return password_verify($password, $hashed_password);
    }
    return false;
}
?>
